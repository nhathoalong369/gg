﻿using AppG4.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppG4.Service
{
    public class HistoryLearningService
    {
        /// <summary>
        /// Lấy danh sách quá trình học tập của một sinh viên dựa vào idStudent
        /// </summary>
        /// <param name="idStudent">Mã sinh viên</param>
        /// <returns>Danh sách quá trình học tập của sinh viên</returns>
        public static List<HistoryLearning> GetListHistoryLearning(string idStudent)
        {
            List<HistoryLearning> histories = new List<HistoryLearning>();
            for(int i = 1; i <= 12; i++)
            {
                HistoryLearning history = new HistoryLearning
                {
                    ID = i.ToString(),
                    YearFrom = 2000 + i,
                    YearEnd = 2001 + i,
                    SchoolName = "Phan Bội Châu",
                    IDStudent = idStudent
                };
                histories.Add(history);
            }
            return histories;
        }
    }
}
