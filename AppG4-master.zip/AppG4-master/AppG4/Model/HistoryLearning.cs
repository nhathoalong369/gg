﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppG4.Model
{
    public class HistoryLearning
    {
        public string ID { get; set; }
        public int YearFrom { get; set; }
        public int YearEnd { get; set; }
        public string SchoolName { get; set; }
        public string IDStudent { get; set; }
        public virtual Student Student { get; set; }
    }
}
